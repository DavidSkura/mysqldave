# mysqldave

A wrapper for simplified MySQL access